"""
verificar_en_pi.py - Se corre en la Raspberry Pi, dentro de la carpeta robot_v7, ANTES de conectar los servos.

Comprueba con los casos grabados en el simulador (prueba_v7.npz) que en la Pi:
  1. la normalización y la red dan la misma acción que en el entrenamiento;
  2. el patrón + la red + el limitador dan los mismos ángulos;
  3. la conversión a pulsos del Maestro es la esperada;
  4. la red responde en < 20 ms.

Requisitos en la Pi: numpy y onnxruntime (pip install onnxruntime) o torch.
Uso:  python verificar_en_pi.py            (usa politica_v7.onnx si existe; si no, politica_v7.pt)
"""
import os
import time

import numpy as np

import patron_v7 as P

HERE = os.path.dirname(os.path.abspath(__file__))
red = os.path.join(HERE, "politica_v7.onnx")
if not os.path.exists(red):
    red = os.path.join(HERE, "politica_v7.pt")
pol = P.Politica(red, os.path.join(HERE, "normalizacion_v7.npz"))
z = np.load(os.path.join(HERE, "prueba_v7.npz"))
print(f"Red: {os.path.basename(red)}  |  casos: {len(np.unique(z['caso']))}, pasos: {len(z['caso'])}")

# 1. red
err_a = max(np.abs(pol(o) - a).max() for o, a in zip(z["obs"], z["accion"]))
print(f"1. acción de la red: error máx {err_a:.2e}  ->  {'OK' if err_a < 1e-4 else 'REVISAR'}")

# 2. patrón + red + limitador
err_q = 0.0
for ic in np.unique(z["caso"]):
    idx = np.where(z["caso"] == ic)[0]
    m = P.Marcha(q_inicial=z["q_start"][idx[0]], de_pie=z["t_start"][idx[0]] == 0)
    for i in idx:
        vx, wz = z["cmd"][i]
        q = m.paso(pol(z["obs"][i]), vx, wz)
        err_q = max(err_q, np.abs(q - z["enviado"][i]).max())
print(f"2. ángulos enviados: error máx {err_q:.2e} rad  ->  {'OK' if err_q < 1e-3 else 'REVISAR'}")

# 3. pulsos de la postura de pie (deben coincidir con tu Maestro)
c = P.a_maestro(P.Q_STAND)
esperado = {0: 6016, 1: 6016, 2: 9480, 15: 6016, 16: 6016, 17: 2552}
ok3 = all(abs(c[k] - v) <= 4 for k, v in esperado.items())
print(f"3. pulsos de pie: LF {c[0]} {c[1]} {c[2]} | RF {c[15]} {c[16]} {c[17]}  "
      f"(esperado 6016 6016 9480 | 6016 6016 2552)  ->  {'OK' if ok3 else 'REVISAR'}")

# 4. tiempo de la red
o = z["obs"][0]
t0 = time.perf_counter()
for _ in range(500):
    pol(o)
dt = (time.perf_counter() - t0) / 500 * 1000
print(f"4. tiempo de la red: {dt:.2f} ms por ciclo  ->  {'OK' if dt < 5 else 'LENTO'}")
