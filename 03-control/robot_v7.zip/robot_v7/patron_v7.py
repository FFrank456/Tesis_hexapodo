"""
patron_v7.py - Todo lo que el robot necesita de la v7, SIN MuJoCo ni Stable-Baselines3.
Solo requiere numpy (y onnxruntime o torch para la red).

Contiene, copiado de hexapod_env.py (v7) sin cambios de comportamiento:
  - constantes de la marcha, postura y comandos
  - Marcha: secuencia de levantarse + patrón trípode del Maestro + corrección de la red + limitador
  - Observador: filtro complementario, rumbo de referencia y las 54 entradas en el orden exacto
  - Politica: normalización + red del actor (ONNX o TorchScript)
  - conversión de ángulos (rad del URDF) a cuartos de µs del Pololu Maestro

Uso en el robot (cada 20 ms):
    obs = observador.actualizar(gyro, acc, contactos, marcha.t_marcha(), comando)
    a   = politica(obs)
    q   = marcha.paso(a, comando)              # rad, orden de actuadores ACT
    canales = a_maestro(q)                     # dict canal -> cuartos de µs
    observador.recordar_accion(a)
"""
import numpy as np

# ------------------------------------------------------------------ constantes (hexapod_env.py v7)
DT = 0.02                    # s, ciclo de control (50 Hz)
FEMUR_STAND = 0.0            # rad
TIBIA_STAND = 1.36           # rad (78°)
GAIT_T_LIFT = 0.175          # s
GAIT_T_SWING = 0.25          # s
GAIT_PERIOD = 2 * (2 * GAIT_T_LIFT + GAIT_T_SWING)   # 1.2 s
COXA_AMP = 0.236             # rad
FEMUR_LIFT = 0.78            # rad
RES_SCALE = 0.25             # rad, corrección máxima de la red
T_RAMP = 1.0                 # s
T_STANDUP = 1.6              # s
V_NOM = 0.105                # m/s con k = 1
W_NOM = 0.53                 # rad/s con kw = 1
VX_MAX = 0.12                # m/s, comando máximo
WZ_MAX = 0.5                 # rad/s, comando máximo
HEAD_ERR_MAX = 0.5           # rad
CMD_RATE = 0.12              # rad por ciclo (limitador)
Q_LIM = 1.570796             # rad, ±90°
CF_ALPHA = 0.98              # filtro complementario
TRIPOD_A = ["l1", "r2", "l3"]
LEGS = ["l1", "l2", "l3", "r1", "r2", "r3"]          # orden de los finales de carrera en la observación

# orden de los 18 actuadores (= orden de la red y de la acción)
ACT = [f"{j}_{l}" for l in ["l3", "l2", "l1", "r3", "r2", "r1"] for j in ["coxa", "femur", "tibia"]]

# Pololu Mini Maestro 18 (de maestro_settings.txt): LF 0-2 | LM 3-5 | LR 6-8 | RR 9-11 | RM 12-14 | RF 15-17
MAESTRO_CANAL = {"coxa_l1": 0, "femur_l1": 1, "tibia_l1": 2, "coxa_l2": 3, "femur_l2": 4, "tibia_l2": 5,
                 "coxa_l3": 6, "femur_l3": 7, "tibia_l3": 8, "coxa_r3": 9, "femur_r3": 10, "tibia_r3": 11,
                 "coxa_r2": 12, "femur_r2": 13, "tibia_r2": 14, "coxa_r1": 15, "femur_r1": 16, "tibia_r1": 17}
NEUTRO_US = 1504.0           # µs (Maestro 6016 = pose estrella)
US_POR_RAD = 1000.0 / (np.pi / 2)        # 1000 µs = 90°
SIGNO_US = {"coxa": 1.0, "femur": 1.0, "tibia": -1.0}
# corrección de centro por servo (µs), para calibrar cada uno en el robot real
OFFSET_US = {n: 0.0 for n in MAESTRO_CANAL}

_side = np.array([1.0 if "_l" in n else -1.0 for n in ACT])
_is_coxa = np.array([n.startswith("coxa") for n in ACT], float)
_is_femur = np.array([n.startswith("femur") for n in ACT], float)
_groupA = np.array([n.split("_")[1] in TRIPOD_A for n in ACT])
Q_STAND = np.array([0.0 if n.startswith("coxa") else
                    (s * FEMUR_STAND if n.startswith("femur") else -s * TIBIA_STAND)
                    for n, s in zip(ACT, _side)])
Q_ESTRELLA = np.zeros(18)


def _smooth(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def tripod_pattern(t, kL, kR, w=1.0):
    """Marcha trípode del Maestro en el instante t (s). Devuelve 18 ángulos (rad)."""
    half = GAIT_PERIOD / 2
    fl, fs = GAIT_T_LIFT / half, GAIT_T_SWING / half
    phi = (t % GAIT_PERIOD) / GAIT_PERIOD
    air = np.where(_groupA, phi >= 0.5, phi < 0.5)
    u = np.where(phi >= 0.5, phi - 0.5, phi) / 0.5
    lift = np.where(air, np.minimum(_smooth(u / fl), 1 - _smooth((u - fl - fs) / fl)), 0.0)
    sweep = _smooth((u - fl) / fs)
    c = np.where(air, -1 + 2 * sweep, 1 - 2 * sweep)
    k = np.where(_side > 0, kL, kR)
    q = Q_STAND.copy()
    q = q + _is_coxa * _side * w * COXA_AMP * k * c
    q = q + _is_femur * _side * w * FEMUR_LIFT * lift
    return q


def gait_k(vx, wz):
    kv, kw = vx / V_NOM, wz / W_NOM
    return float(np.clip(kv - kw, -1.3, 1.3)), float(np.clip(kv + kw, -1.3, 1.3))


class Marcha:
    """Levantarse + patrón + corrección de la red + limitador (idéntico al simulador)."""
    def __init__(self, q_inicial=Q_ESTRELLA, de_pie=False):
        self.q_start = np.asarray(q_inicial, float).copy()
        self.t_start = 0.0 if de_pie else T_STANDUP
        self.steps = 0
        self.cmd = self.q_start.copy()            # último ángulo enviado (para el limitador)

    def t_marcha(self):
        """Tiempo de marcha (s); negativo mientras se levanta."""
        return self.steps * DT - self.t_start

    def base(self, vx, wz):
        t_abs = self.steps * DT
        lift = _is_femur * _side * FEMUR_LIFT
        if t_abs < self.t_start:
            p = t_abs / self.t_start
            a = self.q_start * (1 - _is_femur) + (Q_STAND + lift) * _is_femur
            b = Q_STAND + lift
            if p < 0.25:
                return self.q_start + _smooth(p / 0.25) * (a - self.q_start)
            if p < 0.625:
                return a + _smooth((p - 0.25) / 0.375) * (b - a)
            return b + _smooth((p - 0.625) / 0.375) * (Q_STAND - b)
        t = t_abs - self.t_start
        w = _smooth(t / T_RAMP)
        kL, kR = gait_k(vx, wz)
        q = tripod_pattern(t, kL, kR, w)
        q_from = self.q_start if self.t_start == 0 else Q_STAND
        return q_from + w * (q - q_from) if w < 1 else q

    def paso(self, a, vx, wz):
        """a: salida de la red (18, en [-1, 1]). Devuelve los ángulos a enviar (rad)."""
        a = np.clip(np.asarray(a, float), -1, 1)
        target = np.clip(self.base(vx, wz) + RES_SCALE * a, -Q_LIM, Q_LIM)
        target = self.cmd + np.clip(target - self.cmd, -CMD_RATE, CMD_RATE)
        self.cmd = target
        self.steps += 1
        return target


class Observador:
    """Filtro complementario + rumbo de referencia + las 54 entradas de la red."""
    def __init__(self, alpha=CF_ALPHA, g_inicial=(0.0, 0.0, -1.0)):
        self.alpha = alpha
        self.g = np.array(g_inicial, float)
        self.yaw = 0.0
        self.ref = 0.0
        self.a1 = np.zeros(18)                    # acción anterior
        self.a2 = np.zeros(18)                    # acción de hace 2 ciclos

    def imu(self, gyro, acc):
        """gyro (rad/s) y acc (m/s², fuerza específica: nivelado y quieto ≈ (0, 0, +9.81))
        en el MARCO DEL CUERPO: x adelante, y izquierda, z arriba."""
        gyro, acc = np.asarray(gyro, float), np.asarray(acc, float)
        g = self.g - DT * np.cross(gyro, self.g)
        a_dir = -acc / max(np.linalg.norm(acc), 1e-6)
        g = self.alpha * g + (1 - self.alpha) * a_dir
        self.g = g / np.linalg.norm(g)
        self.yaw += gyro[2] * DT
        self.gyro = gyro

    def rumbo(self, wz_cmd):
        self.ref += wz_cmd * DT
        self.ref = self.yaw + np.clip(self.ref - self.yaw, -HEAD_ERR_MAX, HEAD_ERR_MAX)

    def obs(self, contactos, t_marcha, vx_cmd, wz_cmd):
        """contactos: 6 valores 0/1 en el orden LEGS (l1, l2, l3, r1, r2, r3)."""
        e = self.yaw - self.ref
        ph = 2 * np.pi * max(0.0, t_marcha) / GAIT_PERIOD
        return np.concatenate([self.g, 0.25 * self.gyro, [np.sin(e), np.cos(e)],
                               self.a1, self.a2, np.asarray(contactos, float),
                               [np.sin(ph), np.cos(ph)], [vx_cmd / VX_MAX, wz_cmd / WZ_MAX]]).astype(np.float32)

    def recordar_accion(self, a):
        self.a2 = self.a1
        self.a1 = np.clip(np.asarray(a, float), -1, 1)


class Politica:
    """Normalización (de vecnormalize.pkl) + red del actor. Prefiere ONNX; si no, TorchScript."""
    def __init__(self, ruta_red, ruta_norm):
        z = np.load(ruta_norm)
        self.mean, self.var = z["mean"], z["var"]
        self.clip, self.eps = float(z["clip_obs"]), float(z["epsilon"])
        if ruta_red.endswith(".onnx"):
            import onnxruntime as ort
            self.sess = ort.InferenceSession(ruta_red, providers=["CPUExecutionProvider"])
            self.inp = self.sess.get_inputs()[0].name
            self.run = lambda x: self.sess.run(None, {self.inp: x})[0]
        else:
            import torch
            self.net = torch.jit.load(ruta_red).eval()
            self.run = lambda x: self.net(torch.from_numpy(x)).detach().numpy()

    def normalizar(self, obs):
        return np.clip((obs - self.mean) / np.sqrt(self.var + self.eps), -self.clip, self.clip).astype(np.float32)

    def __call__(self, obs):
        a = self.run(self.normalizar(obs)[None, :])[0]
        return np.clip(a, -1.0, 1.0)


def a_maestro(q):
    """Ángulos (rad, orden ACT) -> {canal: cuartos de µs} para el comando 0x84 del Maestro."""
    out = {}
    for n, val in zip(ACT, q):
        us = NEUTRO_US + OFFSET_US[n] + SIGNO_US[n.split("_")[0]] * val * US_POR_RAD
        out[MAESTRO_CANAL[n]] = int(round(4 * us))
    return out


def comando_maestro_0x84(canal, cuartos_us):
    """Bytes del protocolo compacto del Maestro: 0x84, canal, 7 bits bajos, 7 bits altos."""
    return bytes([0x84, canal, cuartos_us & 0x7F, (cuartos_us >> 7) & 0x7F])
